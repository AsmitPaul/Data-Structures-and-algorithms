<?php
$string = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
$string_shuffled = str_shuffle($string);

$half = substr($string_shuffled, 1, 7);

echo $half ;
 ?>
