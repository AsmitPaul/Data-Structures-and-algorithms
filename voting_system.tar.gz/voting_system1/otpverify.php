<?php
session_start();
$userotp=$_POST['otp'];
$con=new mysqli("localhost","root","","project") or die (Error.mysqli_error());
$sql="select AADHAR_NO from voting where OTP='$userotp'";
$res=$con->query($sql) or die (Error.mysqli_error());
if ($res->num_rows==1){
	header("location:cam.html");
}
else{
	$_SESSION["otp_ses"]="Invalid OTP!";
	header("location:otp.php");
}
?>