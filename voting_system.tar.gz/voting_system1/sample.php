<?php


require("php_serial.class.php");
$adno=$_POST['aadhar'];
$serial = new phpSerial;

// First we must specify the device. This works on both linux and windows (if
// your linux serial device is /dev/ttyS0 for COM1, etc)
$serial->deviceSet("COM3");

// We can change the baud rate, parity, length, stop bits, flow control
$serial->confBaudRate(9600);
$serial->confParity("none");
$serial->confCharacterLength(8);
$serial->confStopBits(1);
$serial->confFlowControl("none");

// Then we need to open it
$serial->deviceOpen();  

$con=new mysqli("localhost","root","","project") or die (Error.mysqli_error());

$sql="select MOBILE_NO from voting where AADHAR_NO=$adno";
$res=$con->query($sql) or die (Error.mysqli_error());
while($row=$res->fetch_assoc()){
	$value=$row["MOBILE_NO"];
}
//echo $value;
// To write into
//Code to genrate OTP

$string = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
$string_shuffled = str_shuffle($string);
$otp = substr($string_shuffled, 1, 7);
echo $otp;
$sql1="update voting set OTP='$otp' where AADHAR_NO=$adno";
$res1=$con->query($sql1) or die (Error.mysqli_error());
$serial->sendMessage("AT+CMGF=1\n\r");
$serial->sendMessage("AT+CMGS=\"$value\"\n\r");
$serial->sendMessage("Hello User, Your OTP is : $otp \n\r");
$serial->sendMessage(chr(26));

//wait for modem to send message
sleep(7);


// Or to read from
$read = $serial->readPort();
echo $read;
// If you want to change the configuration, the device must be closed
$serial->deviceClose();
header("location:otp.php");
?>