<?php
session_start();
$aadno=$_POST['sample'];
$con=new mysqli("localhost","root","","project") or die (Error.mysqli_error());
$sql="select AADHAR_NO from voting where AADHAR_NO='$aadno'";
$res=$con->query($sql) or die (Error.mysqli_error());
if ($res->num_rows==1){
	header("location:otp.php");
}
else{
	$_SESSION["sample_ses"]="Data Unavailable!";
	header("location:home.html");
}
?>