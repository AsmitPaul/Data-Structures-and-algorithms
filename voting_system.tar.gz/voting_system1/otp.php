<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style type="text/css">
  body{
        background-image:url(otpback.png);
        background-repeat:no-repeat;
        background-size:cover;
}
</style>
<style type="text/css">
 h2{color:white;
}
</style>
<style>
input[type=text],select{
   width:50%;
   padding:15px 30px;
   margin:8px 0;
   display:inline-block;
   border:1px solid #ccc;
   border-radius:4px;
   box-sizing:border-box;
   }
  input[type=submit]{
  width:30%;
  background-color:blue;
  color:white;
  padding:14px 20px;
  margin:8px 0;
  border:none;
  border-radius:4px;
  cursor:pointer;
  }
 input[type=submit]:hover{
 background-color:#45a049;
 }
 div{
 text-align:center;
 border-radius:80px;
 background-color:black;
 padding:200px 05px;
 margin-top:200px;
 margin-left:500px;
 margin-right:500px;}
</style>
</head>
<body>
<div>
 <form method="POST" action="otpverify.php">
  <label for="fnum"><h2>ENTER THE OTP NUMBER</h2></label>
  <input type="text" id="fnum" name="otp">
  <br>
  <input type="submit" value="submit">
  </form>
  </div>
  <?php 
  session_start();
  echo $_SESSION["otp_ses"] ?>
</html>


